
public class Nodo {
    int dato;
    Nodo next;
    Nodo prev;
    public Nodo(int dato) {
        this.dato = dato;
        this.next = null;
        this.prev = null;
    }

}
