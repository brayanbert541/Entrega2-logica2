public class Nodo {
    int dato; //contenido del nodo
    Nodo siguiente; //Puntero al siguiente nodo

    public Nodo(int dato){
        this.dato = dato; //Instanciar el dato
        this.siguiente = null;

    }
}
